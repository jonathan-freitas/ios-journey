import UIKit

// ------------ ENCAPSULATION ------------
//> This is a 'Music' class that encapsulates an array of notes and allow you to flatten it into a string with the 'prepared()' method.
class Music {
    let notes: [String]
    init(notes: [String]) {
        self.notes = notes
    }
    
    func prepared() -> String {
        return notes.joined(separator: " ")
    }
}

// ------------ ROOT CLASS ------------
//> Root class of the intruments hierarchy. It defines the blueprint which forms the basis of any kind of instrument. Because it's a type, the name 'Instrument' is capitalized. It doesn't have to be capitalized, however this is a convention in Swift
//> The stored properties in this case is just the brand, which is represented by a string.
class Instrument {
    let brand: String
    init(brand: String){
        self.brand = brand
    }
    
    func tune() -> String {
        fatalError("Implement this method for \(brand)")
    }
    
    //> This method returns a string to be played.
    func play(_ music: Music) -> String {
        return music.prepared()
    }
    
    //> This method first tunes the intrument and then plays the music given in one go.
    func perform(_ music: Music) {
        print(tune())
        print(play(music))
    }
}

// ------------ INHERITANCE ------------
//> Piano is a subclass of the 'Instrument' parent class. All the stored properties and methods are automatically inherited by the Piano child class and available to use
//> All the pianos have the same exactly number of white and black keys regardless of their brand. The associated values of their corresponding properties don`t change dynamically, so you mark the properties as static in order to reflect this
class Piano: Instrument {
    let hasPedals: Bool
    static let whiteKeys = 52
    static let blackKeys = 36
    
    init(brand: String, hasPedals: Bool = false) {
        self.hasPedals = hasPedals
        super.init(brand: brand)
    }
    
    override func tune() -> String {
        return "Piano standard tuning for \(brand)."
    }
    
    override func play(_ music: Music) -> String {
        return play(music, usingPedals: hasPedals)
    }
    
    //> This overloads the 'play(_ :)' method to use pedals if usingPedals is true and the piano actually has pedals to use. It does not use the override keyword because it has a different parameter list. Swift uses the parameter list (aka signature) to determine which to use. You need to be careful with overloaded methods though because they have the potencial to cause confunsion. For example, the 'perfom(_:)' method always calls the 'play(_:)' one, and will never call your specialized 'play(_:usingPedals)' one.
    func play(_ music: Music, usingPedals: Bool) -> String {
        let preparedNotes = super.play(music)
        if hasPedals && usingPedals {
            return "Play piano notes \(preparedNotes) with pedals."
        } else {
            return "Play piano notes \(preparedNotes) without pedals."
        }
    }
    
    func play(_ music: Music, numberOfTheBeast: Int){
        print("\(numberOfTheBeast)")
    }
    
}

// ------------ INTERMEDIATE ABSTRACT BASE CLASSES ------------
//> This creates a new class 'Guitar' that adds the idea os string gauge as a text to the 'Instrument' base class. Like 'Instrument', 'Guitar' is considered
//> an abstract type whose 'tune()' and 'play(_:)' methods need to be overriden in a subclass. This is why its sometimes called a 'Intermediate Abstract Base Class'
class Guitar: Instrument {
    private let stringGauge: String
    init(brand: String, stringGauge: String = "medium") {
        self.stringGauge = stringGauge
        super.init(brand: brand)
    }
}


// ------------ CONCRETE GUITAR ------------
//> All acoustic guitars have 6 strings and 20 frets, so you model the corresponding properties as static because they relate to all acoustic guitars.
//> And they are constants since their values never change over time. The class doesn’t add any new stored properties of its own, so you don’t need to create
//> an initializer, as it automatically inherits the initializer from its parent class, 'Guitar'.
class AcousticGuitar: Guitar {
    static let numberOfStrings = 6
    static let fretCount = 20
    
    override func tune() -> String {
        return "Tune \(brand) acoustic with E A D G B E"
    }
    
    override func play(_ music: Music) -> String {
        let preparedNotes = super.play(music)
        return "Play folk tune on frets \(preparedNotes)."
    }
}

// ------------ ROOT CLASS ------------
//> The underscore behind the volume property emphasizes that it is a private property.
//> The stored property isOn can be read by outside users but not written to. This is done with 'private(set)'.
class Amplifier {
    private var _volume: Int
    private(set) var isOn: Bool
    
    init(){
        isOn = false
        _volume = 0
    }
    
    //> Both methods 'plugIn()' and 'plugOff()' affect the state of 'isOn'.
    func plugIn(){
        isOn = true
    }
    
    func plugOff(){
        isOn = false
    }
    
    //> The computed property named 'volume' wraps the private stored property '_volume'.
    var volume: Int {
        
        //> The getter drops the volume to 0 if it's not plugged int.
        get {
            return isOn ? _volume : 0
        }
        
        //> The volume will always be clamped to a certain value between 0 and 10 inside the setter.
        set{
            _volume = min(max(newValue, 0), 10)
        }
    }
}

// ------------ CONCRETE GUITAR ------------
//> An electric guitar contains an amplifier. This is a has-a relationship and not an is-a relationship as with inheritance.
class ElectricGuitar: Guitar {
    let amplifier: Amplifier
    
    //> A custom initializer that initializes all of the stored properties and then calls the super class.
    init(brand: String, stringGauge: String = "light", amplifier: Amplifier) {
        self.amplifier = amplifier
        super.init(brand: brand, stringGauge: stringGauge)
    }
    
    override func tune() -> String {
        amplifier.plugIn()
        amplifier.volume = 5
        return "Tune \(brand) electric with E A D G B E"
    }
    
    override func play(_ music: Music) -> String {
        let preparedNotes = super.play(music)
        return "Play solo \(preparedNotes) at volume \(amplifier.volume)."
    }
}

// ------------ CONCRETE TYPES ------------
class BassGuitar: Guitar {
    let amplifier: Amplifier
    
    init(brand: String, stringGauge: String = "heavy", amplifier: Amplifier) {
        self.amplifier = amplifier
        super.init(brand: brand, stringGauge: stringGauge)
    }
    
    override func tune() -> String {
        amplifier.plugIn()
        return "Tune \(brand) bass with E A D G"
    }
    
    override func play(_ music: Music) -> String {
        let preparedNotes = super.play(music)
        return "Play bass line \(preparedNotes) at volume \(amplifier.volume)."
    }
}

// ------------ POLYMORPHISM -----------
//> This class has an instruments array stored property which you set in the initializer. The band perfoms live on stage by going through the instruments array in a for in loop and calling the 'perform(_:)' method for each instrument in the array
class Band {
    let instruments: [Instrument]
    
    init(instruments: [Instrument]) {
        self.instruments = instruments
    }
    
    func perform(_ music: Music) {
        for instrument in instruments {
            instrument.perform(music)
        }
    }
}

// -------------- PIANO --------------
//> Create an instance of the Piano class
//> Tuning the Piano
//> Playing the Piano
let piano = Piano(brand: "Yamaha", hasPedals: true)
piano.tune()

let music = Music(notes: ["C", "G", "F"])
piano.play(music, usingPedals: false)

piano.play(music)

piano.play(music, numberOfTheBeast: 666)

Piano.whiteKeys
Piano.blackKeys
// --------------- ACOUSTIC GUITAR --------------
//> Follow the same to-do as the 'Piano' above
let acousticGuitar = AcousticGuitar(brand: "Roland", stringGauge: "light")
acousticGuitar.tune()
acousticGuitar.play(music)
// --------------- ELECTRIC & BASS GUITAR --------------
let amplifier = Amplifier()
let electricGuitar = ElectricGuitar(brand: "Gibson", stringGauge: "medium", amplifier: amplifier)
electricGuitar.tune()

let bassGuitar = BassGuitar(brand: "Fender", stringGauge: "heavy", amplifier: amplifier)
bassGuitar.tune()

//> Notice that because of class reference semantics, the amplifier is a shared resource between these two guitars.

bassGuitar.amplifier.volume
electricGuitar.amplifier.volume

bassGuitar.amplifier.plugOff()
bassGuitar.amplifier.volume
electricGuitar.amplifier.volume

bassGuitar.amplifier.plugIn()
bassGuitar.amplifier.volume
electricGuitar.amplifier.volume
// ---------------- BAND -------------
let instruments = [piano, acousticGuitar, electricGuitar, bassGuitar]
let band = Band(instruments: instruments)
band.perform(music)


